﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WriteCommandAreasToShe
{
  public class CodeWriter
  {

    private string _path;
    private string _nameSpace;
    private MetaSection _msection;

    private List<string> _propertyNames = new List<string>();


    public CodeWriter(string Path, string NameSpace)
    {
      _path = Path;
      _nameSpace = NameSpace;
    }

    public void WriteClass(MetaSection MSection)
    {
      _msection = MSection;
      _propertyNames.Clear();
      _propertyNames.Add(MSection._className);
      using (StreamWriter SW = new StreamWriter(Path.Combine(_path, MSection._className + ".cs"),false,Encoding.Default))
      {
        WriteHeader(SW);
        WriteMembers(SW);
        WriteConstructor(SW);
        WriteOtherProperties(SW);
        WriteSimleTypeProperties(SW);
        SW.WriteLine("  }");
        SW.WriteLine("}");
      }
    }

    /// <summary>
    /// Writes the member section
    /// </summary>
    /// <param name="SW"></param>
    private void WriteMembers(StreamWriter SW)
    {

      //Each section gives a member
      foreach (MetaSection item in _msection._subSections)
      {
        SW.WriteLine("    private " + item._className + " " + item.PrivateName + ";");
      }

      //Each list with sections gives a member
      foreach (MetaSection item in _msection._subSectionLists)
      {
        SW.WriteLine("    private List<" + item._className + "> " + item.PrivateName + "s = new List<" + item._className + ">();");
      }

      //Each Multiparameter gives a member
      //foreach (MetaKeywordMultiParameter item in _msection._multiPars)
      //{
      //  SW.WriteLine("    private " + item._className + " " + item.PrivateName + ";");
      //}

      SW.WriteLine();

    }

    private void WriteConstructor(StreamWriter SW)
    {
      SW.WriteLine("    internal " + _msection._className + "(PFSSection Section)");
      SW.WriteLine("    {");
      SW.WriteLine("      _pfsHandle = Section;");
      SW.WriteLine();
      SW.WriteLine("      for (int i = 1; i <= Section.GetSectionsNo(); i++)");
      SW.WriteLine("      {");
      SW.WriteLine("        PFSSection sub = Section.GetSection(i);");
      SW.WriteLine("        switch (sub.Name)");
      SW.WriteLine("        {");

      foreach (MetaSection MS in _msection._subSections)
      {
        SW.WriteLine("        case \"" + MS._pfstype + "\":");
        SW.WriteLine("          " + MS.PrivateName + " = new " + MS._className + "(sub);");
        SW.WriteLine("          break;");
      }



      SW.WriteLine("          default:");

      foreach (MetaSection MSL in _msection._subSectionLists)
      {
        SW.WriteLine("            if (sub.Name.Substring(0,6).Equals(\""+ MSL._pfstype.Substring(0,6)+"\"))");
        SW.WriteLine("            {");
        SW.WriteLine("              "+MSL.PrivateName + "s.Add(new " + MSL._className+"(sub));");
        SW.WriteLine("              break;");
        SW.WriteLine("            }");
      }   
      SW.WriteLine("            _unMappedSections.Add(sub.Name);");
      SW.WriteLine("          break;");
      SW.WriteLine("        }");
      SW.WriteLine("      }");
      SW.WriteLine("    }");
      SW.WriteLine();

    }

    private void WriteOtherProperties(StreamWriter SW)
    {
      foreach (MetaSection MS in _msection._subSections)
      {

        SW.WriteLine("    public " + MS._className + " " + GetUniquePropertyName(MS._name));
        SW.WriteLine("    {");
        SW.WriteLine("     get { return " + MS.PrivateName +"; }");
        SW.WriteLine("    }");
        SW.WriteLine();
      }

      foreach (MetaSection MS in _msection._subSectionLists)
      {
        SW.WriteLine("    public List<" + MS._className + "> " + GetUniquePropertyName(MS._name + "s"));
        SW.WriteLine("   {");
        SW.WriteLine("     get { return " + MS.PrivateName + "s; }");
        SW.WriteLine("    }");
        SW.WriteLine();
      }

    }

    /// <summary>
    /// Returns a unique name for a property. Adds a number if the name has already been used
    /// </summary>
    /// <param name="ProposedName"></param>
    /// <returns></returns>
    private string GetUniquePropertyName(string ProposedName)
    {
      int k = 1;
      string NewName = ProposedName;
      while (_propertyNames.Contains(NewName))
      {
        NewName = ProposedName + k;
        k++;
      }
      _propertyNames.Add(NewName);
      return NewName;
    }



    private void WriteSimleTypeProperties(StreamWriter SW)
    {
      foreach (MetaKeywordSingleParameter MKS in _msection._singlepars)
      {
        //Get a unique name for the property 
        string PropertyName = GetUniquePropertyName(MKS._name);
    

        string cType = "";
        string CastString = "";
        switch (MKS._type)
        {
          case DHI.Generic.MikeZero.PFSParameterType.Boolean:
            cType = "bool";
            CastString = "ToBoolean();";
            break;
          case DHI.Generic.MikeZero.PFSParameterType.Date:
            break;
          case DHI.Generic.MikeZero.PFSParameterType.Double:
            cType = "double";
            CastString = "ToDouble();";
            break;
          case DHI.Generic.MikeZero.PFSParameterType.String:
          case DHI.Generic.MikeZero.PFSParameterType.Missing:
          case DHI.Generic.MikeZero.PFSParameterType.FileName:
            cType = "string";
            CastString = "ToString();";
            break;
          case DHI.Generic.MikeZero.PFSParameterType.Float:
            cType = "float";
            CastString = "ToSingle;";
            break;
          case DHI.Generic.MikeZero.PFSParameterType.Integer:
            cType = "int";
            CastString = "ToInt();";
            break;
          default:
            break;
        }

        SW.WriteLine("    public " + cType + " " + PropertyName);
        SW.WriteLine("    {");
        SW.WriteLine("      get");
        SW.WriteLine("      {");
        SW.WriteLine("        return _pfsHandle.GetKeyword(\"" + MKS._name + "\", 1).GetParameter(1)." + CastString);
        SW.WriteLine("      }");
        SW.WriteLine("      set");
        SW.WriteLine("      {");
        SW.WriteLine("        _pfsHandle.GetKeyword(\"" + MKS._name + "\", 1).GetParameter(1).Value = value;");
        SW.WriteLine("      }");
        SW.WriteLine("    }");
        SW.WriteLine();
      }
    }

    
    private void WriteHeader(StreamWriter SW)
    {
      SW.WriteLine("using System;");
      SW.WriteLine("using System.Collections.Generic;");
      SW.WriteLine("using DHI.Generic.MikeZero;");
      SW.WriteLine();
      SW.WriteLine("namespace " + _nameSpace);
      SW.WriteLine("{");
      SW.Write(@"  /// <summary>
  /// This is an autogenerated class. Do not edit. 
  /// If you want to add methods create a new partial class in another file
  /// </summary>
");
      SW.WriteLine("  public partial class " + _msection._className + ": PFSMapper");
      SW.WriteLine("  {");
      SW.WriteLine();

    }




    public string PathToSource
    {
      get { return _path; }
      set { _path = value; }
    }
  }
}
