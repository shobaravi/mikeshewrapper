﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHI.Generic.MikeZero;

namespace WriteCommandAreasToShe
{
  /// <summary>
  /// This gives a class-property
  /// </summary>
  public class MetaKeywordMultiParameter
  {
    public string _name;
    public string _className;
    public List<string> _parameterNames = new List<string>();
    public List<PFSParameterType> _parTypes = new List<PFSParameterType>();


    public string PrivateName
    {
      get
      {
        return "_" + _name.Substring(0, 1).ToLower() + _name.Substring(1);
      }
    }


    public override string ToString()
    {
      return _name +" <" + _className +">";
    }

    public bool IsEquivalent(MetaKeywordMultiParameter MKM)
    {
      if (!_name.Equals(MKM._name))
        return false;
      if (_parameterNames.Count!= MKM._parameterNames.Count)
        return false;

      for (int i = 0; i <_parameterNames.Count; i++)
      {
        if (!_parameterNames[i].Equals(MKM._name))
          return false;
        if (!_parTypes.Equals(MKM._parTypes))
          return false;
      }
      //Everything checked 
      return true;
    }
  }
}
