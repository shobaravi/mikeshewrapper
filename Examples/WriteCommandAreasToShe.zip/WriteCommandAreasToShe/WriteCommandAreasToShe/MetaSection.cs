﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WriteCommandAreasToShe
{
  public class MetaSection
  {
    public string _pfstype;
    public string _className;
    public string _name;
    public List<MetaSection> _subSections = new List<MetaSection>(); //Property to sections
    public List<MetaKeywordMultiParameter> _multiPars = new List<MetaKeywordMultiParameter>(); //Property to class with simple type properties
    public List<MetaKeywordSingleParameter> _singlepars = new List<MetaKeywordSingleParameter>(); //Property to simple type

    public List<MetaSection> _subSectionLists = new List<MetaSection>(); //Property to list of sections
    public List<MetaKeywordMultiParameter> _multiParsLists = new List<MetaKeywordMultiParameter>(); //Property to List of classes with simple types
    public List<MetaKeywordSingleParameter> _singleparsLists = new List<MetaKeywordSingleParameter>(); //Property to list of simple types


    public string PrivateName
    {
      get
      {
        return "_" + _name.Substring(0,1).ToLower() + _name.Substring(1);
      }
    }

    public override string ToString()
    {
      return _name + " <" + _className + ">";
    }

    public static Predicate<MetaSection> FindEquivalent(MetaSection MS)
    {
      return delegate(MetaSection item) { return (item.IsEquivalent(MS)); };
    }

    public static Predicate<MetaSection> FindListEquivalent(MetaSection MS)
    {
      return delegate(MetaSection item) 
      {
        if (!item._className.Equals(MS._className))
          return false;
        int nameLength = Math.Max(4,item._name.Length - 4);

        if (MS._name.Length < nameLength)
          return false;


        return item._name.Substring(0, nameLength).Equals(MS._name.Substring(0, nameLength)); 
      };
    }


    /// <summary>
    /// Returns true if this section is equivalent. Does not check on section names and types
    /// </summary>
    /// <param name="MS"></param>
    /// <returns></returns>
    public bool IsEquivalent(MetaSection MS)
    {
      if (MS._subSections.Count != _subSections.Count)
        return false;
      if (MS._multiPars.Count != _multiPars.Count)
        return false;
      if (MS._singlepars.Count != _singlepars.Count)
        return false;
      if (MS._subSectionLists.Count != _subSectionLists.Count)
        return false;
      if (MS._multiParsLists.Count != _multiParsLists.Count)
        return false;
      if (MS._singleparsLists.Count != _singleparsLists.Count)
        return false;

      for (int i =0; i < _subSections.Count;i++)
        if (!_subSections[i].IsEquivalent(MS._subSections[i]))
          return false;

      for (int i = 0; i < _subSectionLists.Count; i++)
        if (!_subSectionLists[i].IsEquivalent(MS._subSectionLists[i]))
          return false;

      for (int i = 0; i < _multiPars.Count; i++)
        if (!_multiPars[i].IsEquivalent(MS._multiPars[i]))
          return false;

      for (int i = 0; i < _singlepars.Count; i++)
        if (!_singlepars[i].IsEquivalent(MS._singlepars[i]))
          return false;

      for (int i = 0; i < _multiParsLists.Count; i++)
        if (!_multiParsLists[i].IsEquivalent(MS._multiParsLists[i]))
          return false;

      for (int i = 0; i < _singleparsLists.Count; i++)
        if (!_singleparsLists[i].IsEquivalent(MS._singleparsLists[i]))
          return false;

      //Everything checked
      return true;
    }
  }  
}
