﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHI.Generic.MikeZero;

namespace WriteCommandAreasToShe
{
  /// <summary>
  /// This gives a simple type-property
  /// </summary>
  public class MetaKeywordSingleParameter
  {
    public string _name;
    public PFSParameterType _type;

    public bool IsEquivalent(MetaKeywordSingleParameter MKS)
    {
      if (!MKS._name.Equals(_name))
        return false;
      //One of the keywords are not types. They could be equivalent
      if (_type.Equals(PFSParameterType.Missing) || MKS._type.Equals(PFSParameterType.Missing))
        return true;
      //Integer is equivalent to double
      if (_type.Equals(PFSParameterType.Integer) && MKS._type.Equals(PFSParameterType.Double))
        return true;
      if (_type.Equals(PFSParameterType.Double) && MKS._type.Equals(PFSParameterType.Integer))
        return true;

      //other types should be equal
      return  MKS._type.Equals(_type);
    }

    public override string ToString()
    {
      return _name + " <" + _type + ">";

    }
  }
}
