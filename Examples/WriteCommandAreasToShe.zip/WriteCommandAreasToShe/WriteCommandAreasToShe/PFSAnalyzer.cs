﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHI.Generic.MikeZero;

namespace WriteCommandAreasToShe
{
  public class PFSAnalyzer
  {
    public List<MetaSection> _sectionsRead = new List<MetaSection>();
    List<string> _classNames = new List<string>();
    MetaSection _mother;

    public void ReadPFS(PFSTarget Target)
    {
      _mother = new MetaSection();
      ReadSection(Target, _mother);
      _sectionsRead.Add(_mother);

      Dictionary<string, MetaSection> TypeLibrary = new Dictionary<string, MetaSection>();

      foreach (MetaSection item in _sectionsRead)
      {
        TypeLibrary.Add(item._className, item);
      }
    }


    private void ReadSection(PFSSection Section, MetaSection Meta)
    {
      //Reads name and type for section
      Meta._name = Section.Name;
      Meta._pfstype = Section.Name;
      Meta._className = Section.Name;

      int NumberOfKeywords = Section.GetKeywordsNo();

      //Read all keywords
      for (int i = 1; i <= NumberOfKeywords; i++)
      {
        PFSKeyword Keyword = Section.GetKeyword(i);
        int NumberOfParameters = Keyword.GetParametersNo();
        //Single parameter keyword
        if (NumberOfParameters == 1)
        {
          MetaKeywordSingleParameter MKS = new MetaKeywordSingleParameter();
          MKS._name = Keyword.Name;
          MKS._type = Keyword.GetParameter(1).Type;
          Meta._singlepars.Add(MKS);
        }
          //Multi parameter keyword
        else
        {
          MetaKeywordMultiParameter MKM = new MetaKeywordMultiParameter();
          MKM._name = Keyword.Name;
          MKM._className = Keyword.Name;
          for (int j = 1; j <= NumberOfParameters; j++)
          {
            MKM._parameterNames.Add("Par" + j); //Give default name
            MKM._parTypes.Add(Keyword.GetParameter(j).Type);
          }
          Meta._multiPars.Add(MKM);
        }
      }

      //Read all sections. 
      for (int i = 1; i <= Section.GetSectionsNo(); i++)
      {
        //Creates a new section and adds it.
        MetaSection Sub = new MetaSection();

        //Recursive call
        ReadSection(Section.GetSection(i), Sub);

        //Now see if an equivalent section has already been read
        MetaSection Equivalent = _sectionsRead.Find(MetaSection.FindEquivalent(Sub));
        if (Equivalent == null)
        {
          _sectionsRead.Add(Sub);

          //Keep track of the class names since the same name cannot be used twice
          int k = 1;
          while (_classNames.Contains(Sub._className))
          {
            Sub._className = Sub._pfstype + k; //increment the name by a number
            k++;
          }
          _classNames.Add(Sub._className); //now add the name
        }
        else
        {
          Sub._className = Equivalent._className;
        }



        //Check if this could be a list section
        MetaSection List = Meta._subSections.Find(MetaSection.FindListEquivalent(Sub));

        if (List != null) //A similar section has been added to the subsections
        {
          //Move from subsections to list of subsections
          Meta._subSectionLists.Add(List);
          Meta._subSections.Remove(List);
        }
          //Does it exist as a list?
        if (null == Meta._subSectionLists.Find(MetaSection.FindListEquivalent(Sub)))
          //If not add to sections
          Meta._subSections.Add(Sub);

      }
    }

    /// <summary>
    /// Reads a Keyword and returns the meta-data
    /// </summary>
    /// <param name="Keyword"></param>
    /// <returns></returns>
    private object ReadKeyword(PFSKeyword Keyword)
    {
      int NumberOfParameters = Keyword.GetParametersNo();
      if (NumberOfParameters == 1)
      {
        MetaKeywordSingleParameter MKS = new MetaKeywordSingleParameter();
        MKS._name = Keyword.Name;
        MKS._type = Keyword.GetParameter(1).Type;
        return MKS;
      }
      else
      {
        MetaKeywordMultiParameter MKM = new MetaKeywordMultiParameter();
        MKM._name = Keyword.Name;
        for (int i= 1; i <= NumberOfParameters; i++)
        {
          MKM._parameterNames.Add("Par" + i);
          MKM._parTypes.Add(Keyword.GetParameter(i).Type);
        }
        return MKM;
      }
    }

  }
}

